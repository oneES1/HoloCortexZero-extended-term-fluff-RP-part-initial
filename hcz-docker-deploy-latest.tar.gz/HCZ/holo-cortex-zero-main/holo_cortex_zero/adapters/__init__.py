import asyncio
import contextlib
import importlib
from typing import Dict, Type

from fastapi import APIRouter, FastAPI

from holo_cortex_zero.core.logger import logger

from .interface.base import BaseAdapter

ADAPTER_DICT: Dict[str, str] = {
    "onebot_v11": "holo_cortex_zero.adapters.onebot_v11.adapter.OnebotV11Adapter",
    "telegram": "holo_cortex_zero.adapters.telegram.adapter.TelegramAdapter",
    "matrix": "holo_cortex_zero.adapters.matrix.adapter.MatrixAdapter",
}

loaded_adapters: Dict[str, BaseAdapter] = {}
adapter_init_tasks: Dict[str, asyncio.Task] = {}


def load_adapters_api() -> APIRouter:
    api = APIRouter()
    for adapter_key, adapter_path in ADAPTER_DICT.items():
        module_path = adapter_path.split(".")[:-1]
        try:
            module = importlib.import_module(".".join(module_path))
            adapter_class: Type[BaseAdapter] = getattr(module, adapter_path.split(".")[-1])
            adapter: BaseAdapter = adapter_class()
            api.include_router(adapter.router, prefix=f"/adapters/{adapter_key}", tags=[f"Adapter:{adapter_key}"])
        except Exception:
            logger.exception(f'从 "{adapter_path}" 加载协议端模块 "{adapter_key}" 失败')
            continue
        loaded_adapters[adapter_key] = adapter
    return api


async def init_adapters(_app: FastAPI):
    async def run_adapter_init(adapter_key: str, adapter: BaseAdapter):
        try:
            await adapter.init()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception(f"Adapter {adapter_key} init failed, skip adapter startup")
            with contextlib.suppress(Exception):
                await adapter.cleanup()
            loaded_adapters.pop(adapter_key, None)
            return
        finally:
            adapter_init_tasks.pop(adapter_key, None)
        logger.info(f"Adapter {adapter_key} initialized")

    for adapter_key, adapter in list(loaded_adapters.items()):
        if adapter.init_in_background:
            task = asyncio.create_task(run_adapter_init(adapter_key, adapter), name=f"adapter-init-{adapter_key}")
            adapter_init_tasks[adapter_key] = task
            logger.info(f"Adapter {adapter_key} init scheduled in background")
            continue
        await run_adapter_init(adapter_key, adapter)


async def cleanup_adapters(_app: FastAPI):
    for adapter_key, task in list(adapter_init_tasks.items()):
        if task.done():
            adapter_init_tasks.pop(adapter_key, None)
            continue
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        adapter_init_tasks.pop(adapter_key, None)

    for adapter_key, adapter in list(loaded_adapters.items()):
        await adapter.cleanup()
        logger.info(f"Adapter {adapter_key} cleaned up")


def get_adapter(adapter_key: str) -> BaseAdapter:
    return loaded_adapters[adapter_key]
