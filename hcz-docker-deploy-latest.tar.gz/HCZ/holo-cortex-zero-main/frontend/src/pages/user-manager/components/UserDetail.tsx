import React from 'react'
import {
  Drawer,
  Box,
  Typography,
  Divider,
  CircularProgress,
  Grid,
  Paper,
  useTheme,
  useMediaQuery,
  Button,
} from '@mui/material'
import { useQuery } from '@tanstack/react-query'
import { getUserDetail } from '../../../services/api/user-manager'
import { format } from 'date-fns'
import { useTranslation } from 'react-i18next'

interface UserDetailProps {
  userId: number
  open: boolean
  onClose: () => void
}

const UserDetail: React.FC<UserDetailProps> = ({ userId, open, onClose }) => {
  const { t } = useTranslation('user-manager')
  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down('md'))
  const isSmall = useMediaQuery(theme.breakpoints.down('sm'))

  const { data, isLoading, error } = useQuery({
    queryKey: ['user', userId],
    queryFn: () => getUserDetail(userId),
    enabled: open && !!userId,
  })

  const user = data?.data

  const formatDate = (dateString: string | null) => {
    if (!dateString) return t('common.none', { ns: 'common' })
    try {
      return format(new Date(dateString), isMobile ? 'MM-dd HH:mm' : 'yyyy-MM-dd HH:mm:ss')
    } catch {
      return t('common.invalidDate', { ns: 'common' })
    }
  }

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      PaperProps={{
        sx: {
          width: { xs: '100%', sm: 400, md: 450 },
          display: 'flex',
          flexDirection: 'column',
        },
      }}
    >
      <Box
        sx={{
          p: isSmall ? 1.5 : 2,
          flexGrow: 1,
          overflow: 'auto',
        }}
      >
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            mb: isSmall ? 1 : 2,
            position: 'sticky',
            top: 0,
            backgroundColor: 'background.paper',
            zIndex: 10,
            pb: 1,
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            {isMobile && (
              <Button onClick={onClose} size={isSmall ? 'small' : 'medium'} sx={{ mr: 1, minWidth: 0, textTransform: 'none' }}>
                Back
              </Button>
            )}
            <Typography variant={isSmall ? 'h6' : 'h5'}>{t('detail.title')}</Typography>
          </Box>
          <Button onClick={onClose} size={isSmall ? 'small' : 'medium'} sx={{ minWidth: 0, textTransform: 'none' }}>
            Close
          </Button>
        </Box>

        <Divider sx={{ mb: isSmall ? 1.5 : 2 }} />

        {isLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
            <CircularProgress />
          </Box>
        ) : error ? (
          <Typography color="error">
            {t('detail.loadingError', { error: String(error) })}
          </Typography>
        ) : user ? (
          <Box
            sx={{
              '& .MuiPaper-root': {
                p: isSmall ? 1.5 : 2,
                mb: isSmall ? 1.5 : 2,
              },
            }}
          >
            <Paper>
              <Typography
                variant={isSmall ? 'subtitle2' : 'subtitle1'}
                gutterBottom
                fontWeight="bold"
                sx={{ mb: isSmall ? 1 : 1.5 }}
              >
                {t('detail.basicInfo')}
              </Typography>

              <Grid container spacing={isSmall ? 0.5 : 1}>
                <Grid item xs={4}>
                  <Typography variant={isSmall ? 'caption' : 'body2'} color="text.secondary">
                    {t('table.userId')}
                  </Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography variant={isSmall ? 'caption' : 'body2'}>{user.id}</Typography>
                </Grid>

                <Grid item xs={4}>
                  <Typography variant={isSmall ? 'caption' : 'body2'} color="text.secondary">
                    {t('table.username')}
                  </Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography variant={isSmall ? 'caption' : 'body2'}>{user.username}</Typography>
                </Grid>

                <Grid item xs={4}>
                  <Typography variant={isSmall ? 'caption' : 'body2'} color="text.secondary">
                    {t('table.adapterPlatform')}
                  </Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography variant={isSmall ? 'caption' : 'body2'}>
                    {user.adapter_key}
                  </Typography>
                </Grid>

                <Grid item xs={4}>
                  <Typography variant={isSmall ? 'caption' : 'body2'} color="text.secondary">
                    {t('table.platformUserId')}
                  </Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography variant={isSmall ? 'caption' : 'body2'}>
                    {user.platform_userid}
                  </Typography>
                </Grid>

                <Grid item xs={4}>
                  <Typography variant={isSmall ? 'caption' : 'body2'} color="text.secondary">
                    {t('detail.uniqueId')}
                  </Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography variant={isSmall ? 'caption' : 'body2'}>{user.unique_id}</Typography>
                </Grid>

              </Grid>
            </Paper>

            <Paper>
              <Typography
                variant={isSmall ? 'subtitle2' : 'subtitle1'}
                gutterBottom
                fontWeight="bold"
                sx={{ mb: isSmall ? 1 : 1.5 }}
              >
                {t('detail.otherInfo')}
              </Typography>

              <Grid container spacing={isSmall ? 0.5 : 1}>
                <Grid item xs={4}>
                  <Typography variant={isSmall ? 'caption' : 'body2'} color="text.secondary">
                    {t('table.createdAt')}
                  </Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography variant={isSmall ? 'caption' : 'body2'}>
                    {formatDate(user.create_time)}
                  </Typography>
                </Grid>

                <Grid item xs={4}>
                  <Typography variant={isSmall ? 'caption' : 'body2'} color="text.secondary">
                    {t('detail.updateTime')}
                  </Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography variant={isSmall ? 'caption' : 'body2'}>
                    {formatDate(user.update_time)}
                  </Typography>
                </Grid>
              </Grid>
            </Paper>

            {user.ext_data && Object.keys(user.ext_data).length > 0 && (
              <Paper>
                <Typography
                  variant={isSmall ? 'subtitle2' : 'subtitle1'}
                  gutterBottom
                  fontWeight="bold"
                  sx={{ mb: isSmall ? 1 : 1.5 }}
                >
                  {t('detail.extData')}
                </Typography>

                <Box
                  component="pre"
                  sx={{
                    p: 1,
                    backgroundColor: 'background.default',
                    borderRadius: 1,
                    overflow: 'auto',
                    fontSize: isSmall ? '0.65rem' : '0.75rem',
                    maxHeight: isSmall ? '120px' : '200px',
                  }}
                >
                  {JSON.stringify(user.ext_data, null, 2)}
                </Box>
              </Paper>
            )}
          </Box>
        ) : (
          <Typography>{t('detail.notFound')}</Typography>
        )}
      </Box>

      {isMobile && (
        <Box
          sx={{
            p: 2,
            borderTop: '1px solid',
            borderColor: 'divider',
            mt: 'auto',
          }}
        >
          <Button variant="contained" fullWidth onClick={onClose}>
            {t('actions.back', { ns: 'common' })}
          </Button>
        </Box>
      )}
    </Drawer>
  )
}

export default UserDetail
